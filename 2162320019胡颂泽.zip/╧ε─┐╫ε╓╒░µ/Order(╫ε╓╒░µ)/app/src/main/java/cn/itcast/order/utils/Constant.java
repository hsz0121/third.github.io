package cn.itcast.order.utils;
public class Constant {
    public static final String WEB_SITE = "http://192.168.174.1:8080/order";//内网接口
    public static final String REQUEST_SHOP_URL = "/shop_list_data.json";  //店铺列表接口
}
